<?php
$blindmultiplier = ($tabletype === 't') ? (11 - $allpl) : 4;
switch ($tablelimit)
{
    case 25000:
        $tablemultiplier = 2;
        break;
    
    case 50000:
        $tablemultiplier = 4;
        break;
    
    case 100000:
        $tablemultiplier = 8;
        break;
    
    case 250000:
        $tablemultiplier = 20;
        break;
    
    case 500000:
        $tablemultiplier = 40;
        break;
    
    case 1000000:
        $tablemultiplier = 80;
        break;
    
    default:
        $tablemultiplier = 1;
        break;
}

$SB = ($sbamount != 0) ? $sbamount : (25 * $blindmultiplier * $tablemultiplier);
$BB = ($sbamount != 0) ? $bbamount : (50 * $blindmultiplier * $tablemultiplier);
