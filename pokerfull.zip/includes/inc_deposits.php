
<?php

if ($valid == false)
{
    header('Location: login.php');
}

$html =
            '<div id="content" class="main-content">
                <div class="layout-px-spacing">
                    <h1>Цэнэглэлтын түүх</h1>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th>№</th>
                                <th>Нэр</th>
                                <th>Дүн</th>
                                <th>Илгээсэн</th>
                                <th>Зөвшөөрсөн</th>
                                <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>';
                            $plyrname  = (isset($_SESSION['playername'])) ? addslashes($_SESSION['playername']) : '';
                            $sql = "SELECT * FROM deposits WHERE player_name=:player_name ORDER BY id desc";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute(['player_name' => $plyrname]);
                            $data = $stmt->fetchAll();
                            foreach ($data as $row) {
                                $id = $row['id'];
                                $chipsAmount = transfer_from($row['amount']);
                                $created_at = $row['created_at'];
                                $updated_at = $row['updated_at'];
                                $status = $row['status'];
                                $rowHtml = '<tr><td>'.$id.'</td><td><span style="font-size: 15px;" class="badge badge-info">'.$plyrname.'</span></td><td>'.$chipsAmount.'</td><td>'.$created_at.'</td><td>'.$updated_at.'</td><td>'.$status.'</td></tr>';
                                $html .= $rowHtml;
                            }
                            $html .=
                        '</tbody>
                    </table>
                </div>
            </div>
        </div>';


?>