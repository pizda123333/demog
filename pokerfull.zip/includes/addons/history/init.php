<?php
require 'install.php';
require 'history_general.php';
require 'automove.php';
require 'sidebar_menu.php';
require 'history.php';