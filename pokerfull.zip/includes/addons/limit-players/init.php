<?php
require 'tablesql.php';
require 'chipslog.php';
require 'admin_tables.php';
require 'admin_edit_table.php';
require 'maxtableplayers.php';
require 'tableplayers.php';
require 'tableplayerz.php';
require 'content.php';
