<?php

function rakemod_distpot_winbet( $array = array() )
{
    global $pdo, $tpr;
    $winpot = $array['content'];

    if (!defined('RAKE_TYPE') || !defined('RAKE_COMMISSION_EACHHAND'))
		return $winpot;

	if (RAKE_COMMISSION_EACHHAND != "yes")
	    return $winpot;
	
	if (RAKE_TYPE === "table")
	{
		if (! isset($tpr['rake_comm_pc'], $tpr['rake_comm_cap']))
			return $winpot;

		$percent = (int) $tpr['rake_comm_pc'];
		$capNum  = (int) $tpr['rake_comm_cap'];
	}
	else
	{
		if (!defined('RAKE_COMMISSION') || !defined('RAKE_COMMISSION_CAP'))
			return $winpot;

		$percent = (int) RAKE_COMMISSION;
		$capNum  = (int) RAKE_COMMISSION_CAP;
	}

	$percentage = $percent / 100;
	$cap        = (int) $capNum;
	$commission = floor ( $winpot * $percentage );
	$comMoney   = round ( transfer_from ($commission) );

	if ($cap > 0 && $comMoney > $cap)
		$commission = round( transfer_to( $cap ) / 2 );

	//$result     = $pdo->exec("update " . DB_STATS . " set winpot = winpot + $commission where player = '" . RAKE_COMMISSION_USER . "'");

    return ($winpot - $commission);
}

$addons->add_hook(array(

	'page'     => 'includes/poker_inc.php',
	'location' => 'distpot_winbet_var',
	'function' => 'rakemod_distpot_winbet',

));