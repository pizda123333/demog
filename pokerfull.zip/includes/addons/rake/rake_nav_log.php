<?php
function rake_nav_log($array = array())
{
    $content = $array['content'];

    if (! is_array($content))
    	return $content;

    $content['admin.php?admin=rakelogs'] = 'Rake';
    return $content;
}
$addons->add_hook(array(
	'page'     => 'general',
	'location' => 'nav_log',
	'function' => 'rake_nav_log',
));


function rake_nav_log_content($array = array())
{
	global $pdo, $opsTheme;
	$pagetag = $array['pagetag'];

	if ($pagetag !== 'rakelogs')
		return '';

	$agents   = '';
	$agentStm = $pdo->query("SELECT * FROM " . DB_PLAYERS . " WHERE is_agent = 1");
	while ($agent = $agentStm->fetch(PDO::FETCH_ASSOC))
	{
		$opsTheme->addVariable('option', array(
			'value' => $agent['username'],
			'label' => $agent['username']
		));
		$agents .= $opsTheme->viewPart('rake-select-opt', __DIR__);
	}

	$players   = '';
	$playerStm = $pdo->query("SELECT * FROM " . DB_PLAYERS);
	while ($player = $playerStm->fetch(PDO::FETCH_ASSOC))
	{
		$opsTheme->addVariable('option', array(
			'value' => $player['username'],
			'label' => $player['username']
		));
		$players .= $opsTheme->viewPart('rake-select-opt', __DIR__);
	}

	$opsTheme->addVariable('filter', array(
		'agents'  => $agents,
		'players' => $players,
	));

	$sql  = "SELECT * FROM rake_log WHERE ID > 0";

	if (isset($_POST['agent']) && !empty($_POST['agent']))
	{
		$agent = $_POST['agent'];
		$sql  .= " AND agent = '{$agent}'";
	}
	elseif (isset($_GET['agent']) && !empty($_GET['agent']))
	{
		$agent = $_GET['agent'];
		$sql  .= " AND agent = '{$agent}'";
	}

	if (isset($_POST['player']) && !empty($_POST['player']))
	{
		$player = $_POST['player'];
		$sql  .= " AND player = '{$player}'";
	}
	elseif (isset($_GET['player']) && !empty($_GET['player']))
	{
		$player = $_GET['player'];
		$sql  .= " AND player = '{$player}'";
	}

	if (isset($_POST['daterange']) && !empty($_POST['daterange']))
	{
		$daterange = $_POST['daterange'];
		$dr        = explode('-', $daterange);

		if (count($dr) == 2)
		{
			$startDate = trim($dr[0]);
			$endDate   = trim($dr[1]);
			$sql      .= " AND dated BETWEEN '{$startDate}:00' AND '{$endDate}:59'";
		}
	}

	$sql .= " ORDER BY ID DESC LIMIT 50";

	$logView = '';
	$logs    = $pdo->query($sql);
	while ($log = $logs->fetch(PDO::FETCH_ASSOC))
	{
		$opsTheme->addVariable('log', $log);

		$history = $log['historyID'];
		if (\OPSAddon::isActive('history'))
			$history = $opsTheme->viewPart('rake-history-btn', __DIR__);

		$log['history'] = $history;
		$opsTheme->addVariable('log', $log);
		$logView .= $opsTheme->viewPart('rake-admin-log-each', __DIR__);
	}

	$opsTheme->addVariable('logs', $logView);
	return $opsTheme->viewPage('rake-admin-logs', __DIR__);
}
$addons->add_hook(array(
	'page'     => 'admin.php',
	'location' => 'admin_page',
	'function' => 'rake_nav_log_content',
));
