<?php
require 'tables_omaha.php';
require 'edit_table_omaha.php';
require 'inc_lobby_omaha.php';
require 'poker_inc_omaha.php';
require 'om_poker_head_css.php';