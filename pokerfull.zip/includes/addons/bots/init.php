<?php
require 'pokerinc.php';
require 'nav.php';
require 'general.php';
require 'incpoker.php';
require 'automove.php';
require 'playerjoined.php';
require 'playermove.php';
require 'livegames.php';
require 'adminpost.php';
require 'adminpage.php';
require 'bot-changegod.php';
