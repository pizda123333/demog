<?php
	define('DB_USERCHAT', 'userchat');
	define('DB_LIVECHAT', 'livechat');
	define('DB_PLAYERS', 'players');
	define('DB_STATS', 'stats');
	define('DB_POKER', 'poker');
	define('DB_SETTINGS', 'settings');
	define('DB_STYLES', 'styles');
?>