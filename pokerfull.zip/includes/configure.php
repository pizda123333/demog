<?php 

  
define('DB_SERVER', 'localhost');


define('DB_SERVER_USERNAME', 'root');


define('DB_SERVER_PASSWORD', '');


define('DB_DATABASE', 'ops');


define('ADMIN_USERS', 'admin');


// Additional administrators can be added by seperating admin usernames with commas.


define('MONEY_PREFIX', '');


define('MONEY_DECIMAL', '.');


define('MONEY_THOUSAND', '.');


?>