<?php
/* Styles --- */
$html = '';

if ($_GET['pagename'] === 'poker')
{
	$styles = array(
		$opsTheme->getVariable('theme.url') . '/css/libs.min.css',
		$opsTheme->getVariable('theme.url') . '/css/poker.min.css',
		$opsTheme->getVariable('theme.url') . '/css/modal.css',
		$opsTheme->getVariable('theme.url') . '/css/buttons.css',
		'//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/fontawesome.min.css',	
		'//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/solid.min.css',
	);
}
else
{
	$styles = array(
		$opsTheme->getVariable('theme.url') . '/css/loader.css',
		'https://fonts.googleapis.com/css?family=Nunito:400,600,700',
		$opsTheme->getVariable('theme.url') . '/css/bootstrap.min.css',
		$opsTheme->getVariable('theme.url') . '/css/plugins.css',
		$opsTheme->getVariable('theme.url') . '/css/scrollspyNav.css',
		$opsTheme->getVariable('theme.url') . '/css/theme-checkbox-radio.css',
		$opsTheme->getVariable('theme.url') . '/css/table-basic.css',
		$opsTheme->getVariable('theme.url') . '/css/apexcharts.css',
		$opsTheme->getVariable('theme.url') . '/css/dash_2.css',
		'https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.css',
		$opsTheme->getVariable('theme.url') . '/css/datatable/jquery.dataTables.min.css',
		'https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css',
		$opsTheme->getVariable('theme.url') . '/css/datatable/rowReorder.dataTables.min.css',
		$opsTheme->getVariable('theme.url') . '/css/datatable/responsive.dataTables.min.css',

		

	);
}

foreach ($styles as $style)
{
	$mtime = (substr($style, 0, 2) == '//') ? date('dmYH') : filemtime($style);
	$html .= '<link rel="stylesheet" href="' . $style . '?t=' . $mtime . '">';
}
$opsTheme->addVariable('styles', $html);
/* --- Styles */


/* Scripts --- */
$scriptsHtml = array(
	'header' => '',
	'footer' => '',
);
$scripts = array();
	
	if ($_GET['pagename'] === 'poker')
	{
		/* Header */
		$scripts['header'] = array(
			$opsTheme->getVariable('theme.url') . '/js/jquery-3.4.1.js'
		);
		/* Footer */
		$scripts['footer'] = array(
			$opsTheme->getVariable('theme.url') . '/js/libs.min.js',
			$opsTheme->getVariable('theme.url') . '/js/poker.js',
			$opsTheme->getVariable('theme.url') . '/js/bootstrap.js',
		);
	}
	else
	{
		/* Header */
		$scripts['header'] = array(
			$opsTheme->getVariable('theme.url') . '/css/loader.js',
			$opsTheme->getVariable('theme.url') . '/js/jquery-3.1.1.min.js',
			$opsTheme->getVariable('theme.url') . '/js/popper.min.js',
			$opsTheme->getVariable('theme.url') . '/js/bootstrap.min.js',
			$opsTheme->getVariable('theme.url') . '/js/perfect-scrollbar.min.js',
			$opsTheme->getVariable('theme.url') . '/js/app.js',
			$opsTheme->getVariable('theme.url') . '/js/highlight.pack.js',
			$opsTheme->getVariable('theme.url') . '/js/custom.js',
			$opsTheme->getVariable('theme.url') . '/js/scrollspyNav.js',
			$opsTheme->getVariable('theme.url') . '/js/apexcharts.min.js',
			$opsTheme->getVariable('theme.url') . '/js/dash_2.js',
			'https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.js	',
			$opsTheme->getVariable('theme.url') . '/css/datatable/jquery.dataTables.min.js',
			$opsTheme->getVariable('theme.url') . '/css/datatable/dataTables.rowReorder.min.js',
			$opsTheme->getVariable('theme.url') . '/css/datatable/dataTables.responsive.min.js',
			
			$opsTheme->getVariable('theme.url') . '/css/datatable/button-ext/dataTables.buttons.min.js',
			$opsTheme->getVariable('theme.url') . '/css/datatable/button-ext/jszip.min.js',
			$opsTheme->getVariable('theme.url') . '/css/datatable/button-ext/buttons.html5.min.js',
			$opsTheme->getVariable('theme.url') . '/css/datatable/button-ext/buttons.print.min.js',
		);
		/* Footer */
		$scripts['footer'] = array();
	}

	/* Header */
	foreach ($scripts['header'] as $script)
	{
		$mtime = (substr($script, 0, 2) === '//') ? date('dmYH') : filemtime($script);
		$scriptsHtml['header'] .= '<script type="text/javascript" src="' . $script . '?t=' . $mtime . '"></script>';
	}
	/* Footer */
	foreach ($scripts['footer'] as $script)
	{
		$mtime = (substr($script, 0, 2) === '//') ? date('dmYH') : filemtime($script);
		$scriptsHtml['footer'] .= '<script type="text/javascript" src="' . $script . '?t=' . $mtime . '"></script>';
	}

$opsTheme->addVariable('scripts', array(
	'header' => $scriptsHtml['header'],
	'footer' => $scriptsHtml['footer'],
));
/* --- Scripts */

// START CUSTOM TOP MENU
	$topMenuBar = $sidebarArray;
	// REMOVE NAV ITEMS
	if ($valid == true) unset($topMenuBar['create.php']);
	unset($topMenuBar['login.php']);
	unset($topMenuBar['logout.php']);
	if ($valid == false) unset($topMenuBar['history.php']);
	// ADD NAV ITEMS
	//$topMenuBar['file.php'] = 'Name';
	$tmContent = '';
	foreach ($topMenuBar as $topMenuBarUrl => $topMenuBarLabel)
	{
		$opsTheme->addVariable('tm_menu_url',   $topMenuBarUrl);
		$opsTheme->addVariable('tm_menu_label', $topMenuBarLabel);
		$tmContent .= $opsTheme->viewPart('topmenu-each');
	}
	$opsTheme->addVariable('topmenubar',   $tmContent);
	
// END CUSTOM TOP MENU

// START CUSTOM HEADER VARIABLES
	$tablescount = $pdo->query("select count(*) from ".DB_POKER."")->fetchColumn(); 
	$playerscount = $pdo->query("select count(*) from ".DB_PLAYERS."")->fetchColumn();
	$opsTheme->addVariable('totaltables', $tablescount);
	$opsTheme->addVariable('totalplayers', $playerscount);
// START CUSTOM HEADER VARIABLES
?>