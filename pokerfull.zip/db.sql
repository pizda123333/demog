-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2020 at 08:48 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ops`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `player_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `amount` int(11) DEFAULT 0,
  `status` varchar(250) COLLATE utf8_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(15) NOT NULL,
  `tablename` varchar(64) COLLATE utf8_bin DEFAULT '',
  `pot` int(10) DEFAULT 0,
  `card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card5` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p1pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p1bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p1card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p2pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p2bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p2card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p3pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p3bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p3card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p4pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p4bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p4card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p5pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p5bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p5card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p6pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p6bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p6card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p7pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p7bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p7card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p8pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p8bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p8card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p9pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p9bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p9card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p10pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p10bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p10card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `date` datetime DEFAULT NULL,
  `datez` date DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `gameid` int(11) NOT NULL DEFAULT 0,
  `msg` varchar(500) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `livechat`
--

CREATE TABLE `livechat` (
  `gameID` int(15) NOT NULL DEFAULT 0,
  `updatescreen` int(30) DEFAULT 0,
  `c1` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c2` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c3` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c4` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c5` varchar(150) COLLATE utf8_bin DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `bankname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dans` varchar(50) COLLATE utf8_bin DEFAULT '',
  `dansname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ID` int(11) NOT NULL,
  `username` varchar(12) COLLATE utf8_bin DEFAULT '',
  `huseltdvn` int(12) NOT NULL DEFAULT 0,
  `email` varchar(70) COLLATE utf8_bin DEFAULT '',
  `password` varchar(40) COLLATE utf8_bin DEFAULT '',
  `avatar` varchar(80) COLLATE utf8_bin DEFAULT '',
  `datecreated` int(35) DEFAULT 0,
  `lastlogin` int(35) DEFAULT 0,
  `ipaddress` varchar(20) COLLATE utf8_bin DEFAULT '',
  `sessname` varchar(32) COLLATE utf8_bin DEFAULT '',
  `sessdans` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `banned` tinyint(1) DEFAULT 0,
  `approve` tinyint(1) DEFAULT 0,
  `lastmove` int(35) DEFAULT 0,
  `waitimer` int(35) DEFAULT 0,
  `code` varchar(16) COLLATE utf8_bin DEFAULT '',
  `GUID` varchar(32) COLLATE utf8_bin DEFAULT '',
  `vID` int(15) DEFAULT 0,
  `gID` int(15) DEFAULT 0,
  `timetag` int(30) DEFAULT 0,
  `isbot` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`bankname`, `dans`, `dansname`, `ID`, `username`, `huseltdvn`, `email`, `password`, `avatar`, `datecreated`, `lastlogin`, `ipaddress`, `sessname`, `sessdans`, `banned`, `approve`, `lastmove`, `waitimer`, `code`, `GUID`, `vID`, `gID`, `timetag`, `isbot`) VALUES
('HaanBank', '0', '0', 1, 'admin', 0, '', '8539efcef2b7199f38a1f96dbafc0f33:4a', 'avatar.jpg', 1603698016, 1603698487, '::1', '', NULL, 0, 0, 0, 0, '', '2OmsVNGksYQsbhoIenjoHcZjQ1rvCOZ4', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `poker`
--

CREATE TABLE `poker` (
  `gameID` int(15) NOT NULL,
  `tablename` varchar(64) COLLATE utf8_bin DEFAULT '',
  `tabletype` varchar(1) COLLATE utf8_bin DEFAULT '',
  `tablelow` int(7) DEFAULT 0,
  `tablelimit` varchar(15) COLLATE utf8_bin DEFAULT '',
  `sbamount` int(7) DEFAULT 0,
  `bbamount` int(7) DEFAULT 0,
  `tablestyle` varchar(20) COLLATE utf8_bin DEFAULT '',
  `tplayers` varchar(255) COLLATE utf8_bin DEFAULT '10',
  `gamestyle` varchar(1) COLLATE utf8_bin DEFAULT 't',
  `move` varchar(2) COLLATE utf8_bin DEFAULT '',
  `dealer` varchar(2) COLLATE utf8_bin DEFAULT '',
  `botgod` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `hand` varchar(5) COLLATE utf8_bin DEFAULT '',
  `pot` int(10) DEFAULT 0,
  `bet` int(10) DEFAULT 0,
  `lastbet` varchar(15) COLLATE utf8_bin DEFAULT '',
  `lastmove` int(35) DEFAULT 0,
  `card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `card5` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p1pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p1bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p1card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p1card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p2pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p2bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p2card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p2card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p3pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p3bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p3card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p3card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p4pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p4bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p4card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p4card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p5pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p5bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p5card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p5card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p6pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p6bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p6card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p6card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p7pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p7bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p7card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p7card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p8pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p8bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p8card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p8card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p9pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p9bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p9card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p9card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10name` varchar(12) COLLATE utf8_bin DEFAULT '',
  `p10pot` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p10bet` varchar(10) COLLATE utf8_bin DEFAULT '',
  `p10card1` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10card2` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10card3` varchar(40) COLLATE utf8_bin DEFAULT '',
  `p10card4` varchar(40) COLLATE utf8_bin DEFAULT '',
  `msg` varchar(150) COLLATE utf8_bin DEFAULT '',
  `rake_comm_pc` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `rake_comm_cap` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `rake_log`
--

CREATE TABLE `rake_log` (
  `ID` int(11) NOT NULL,
  `tableID` int(11) NOT NULL DEFAULT 0,
  `historyID` int(11) NOT NULL DEFAULT 0,
  `player` varchar(12) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `commissioner` varchar(12) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `commission` varchar(10) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `agent` varchar(12) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `agent_commission` varchar(10) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `dated` datetime NOT NULL DEFAULT '2020-01-01 00:00:00',
  `tsetting` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting` varchar(12) COLLATE utf8_bin DEFAULT '',
  `Xkey` varchar(12) COLLATE utf8_bin DEFAULT '',
  `Xvalue` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting`, `Xkey`, `Xvalue`) VALUES
('title', 'TITLE', 'Texas Holdem Poker'),
('dans', 'DANS', '5050505050'),
('dansiner', 'DANSINER', 'bat'),
('zar', 'ZAR', ''),
('appmod', 'APPMOD', '0'),
('memmod', 'MEMMOD', '0'),
('movetimer', 'MOVETIMER', '10'),
('showtimer', 'SHOWDOWN', '7'),
('kicktimer', 'KICKTIMER', '7'),
('emailmod', 'EMAILMOD', '0'),
('deletetimer', 'DELETE', '30'),
('waitimer', 'WAITIMER', '0'),
('session', 'SESSNAME', ''),
('renew', 'RENEW', '0'),
('disconnect', 'DISCONNECT', '90'),
('stakesize', 'STAKESIZE', 'high'),
('ipcheck', 'IPCHECK', '0'),
('scriptversio', 'SCRIPTVERSIO', '2.8.1'),
('lastupdatech', 'LASTUPDATECH', '1603697944'),
('updatealert', 'UPDATEALERT', '0'),
('addonupdatea', 'ADDONUPDATEA', '0'),
('licensekey', 'LICENSEKEY', ''),
('activationca', 'ACTIVATIONCA', ''),
('theme', 'THEME', 'pokersite'),
('themeupdatea', 'THEMEUPDATEA', '0');

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE `stats` (
  `ID` int(11) NOT NULL,
  `player` varchar(12) COLLATE utf8_bin DEFAULT '',
  `rank` varchar(12) COLLATE utf8_bin DEFAULT '',
  `winpot` int(20) UNSIGNED NOT NULL DEFAULT 0,
  `sefdvn` int(20) UNSIGNED NOT NULL DEFAULT 0,
  `gamesplayed` int(11) DEFAULT 0,
  `tournamentsplayed` int(11) DEFAULT 0,
  `tournamentswon` int(11) DEFAULT 0,
  `handsplayed` int(11) DEFAULT 0,
  `handswon` int(11) DEFAULT 0,
  `bet` int(11) DEFAULT 0,
  `checked` int(11) DEFAULT 0,
  `called` varchar(11) COLLATE utf8_bin DEFAULT '0',
  `allin` varchar(11) COLLATE utf8_bin DEFAULT '0',
  `fold_pf` varchar(11) COLLATE utf8_bin DEFAULT '0',
  `fold_f` varchar(11) COLLATE utf8_bin DEFAULT '0',
  `fold_t` varchar(11) COLLATE utf8_bin DEFAULT '0',
  `fold_r` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `stats`
--

INSERT INTO `stats` (`ID`, `player`, `rank`, `winpot`, `sefdvn`, `gamesplayed`, `tournamentsplayed`, `tournamentswon`, `handsplayed`, `handswon`, `bet`, `checked`, `called`, `allin`, `fold_pf`, `fold_f`, `fold_t`, `fold_r`) VALUES
(1, 'admin', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0', '0', '0', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `styles`
--

CREATE TABLE `styles` (
  `style_id` int(11) NOT NULL,
  `style_name` varchar(20) COLLATE utf8_bin DEFAULT '',
  `style_lic` varchar(60) COLLATE utf8_bin DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `styles`
--

INSERT INTO `styles` (`style_id`, `style_name`, `style_lic`) VALUES
(1, 'table_blue', 'yTKWShHyXw');

-- --------------------------------------------------------

--
-- Table structure for table `userchat`
--

CREATE TABLE `userchat` (
  `gameID` int(11) NOT NULL DEFAULT 0,
  `updatescreen` int(30) DEFAULT 0,
  `c1` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c2` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c3` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c4` varchar(150) COLLATE utf8_bin DEFAULT '',
  `c5` varchar(150) COLLATE utf8_bin DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `withdrawal`
--

CREATE TABLE `withdrawal` (
  `id` int(11) NOT NULL,
  `player_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `tatsandvn` int(11) NOT NULL,
  `bankniner` varchar(250) COLLATE utf8_bin NOT NULL,
  `dansnidugaar` varchar(50) COLLATE utf8_bin NOT NULL,
  `dansniner` varchar(250) COLLATE utf8_bin NOT NULL,
  `status` varchar(250) COLLATE utf8_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `livechat`
--
ALTER TABLE `livechat`
  ADD PRIMARY KEY (`gameID`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `poker`
--
ALTER TABLE `poker`
  ADD PRIMARY KEY (`gameID`);

--
-- Indexes for table `rake_log`
--
ALTER TABLE `rake_log`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `styles`
--
ALTER TABLE `styles`
  ADD PRIMARY KEY (`style_id`);

--
-- Indexes for table `userchat`
--
ALTER TABLE `userchat`
  ADD PRIMARY KEY (`gameID`);

--
-- Indexes for table `withdrawal`
--
ALTER TABLE `withdrawal`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `poker`
--
ALTER TABLE `poker`
  MODIFY `gameID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rake_log`
--
ALTER TABLE `rake_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stats`
--
ALTER TABLE `stats`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `styles`
--
ALTER TABLE `styles`
  MODIFY `style_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `withdrawal`
--
ALTER TABLE `withdrawal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
