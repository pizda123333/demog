<?php 

    $html =
        '<h3>Ашиг</h3>
                <table id="html5-extension" class="table table-striped">
                    <thead>
                        <tr>
                            <th>№</th>
                            <th>Хожсон тоглогч</th>
                            <th>Ашиг</th>
                            <th>Огноо</th>
                            <th>Ширээ №</th>
                            <th>Түүх №</th>
                        </tr>
                        </thead>
                        <tbody>';
    $limit = 100;  //how many items to show per page
    $page = (isset($_GET['page'])) ? $_GET['page'] : 1;
    if($page)
    $start = ($page - 1) * $limit;      //first item to display on this page
    else
    $start = 0;
    $sql = "SELECT * FROM rake_log ORDER BY id desc LIMIT $start, $limit";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $data = $stmt->fetchAll();

    foreach ($data as $row) {
        $ID = $row['ID'];
        $tableID = $row['tableID'];
        $historyID = $row['historyID'];
        $player = $row['player'];
        $commission = $row['commission'];
        $dated = $row['dated'];


        
        $rowHtml = '<tr><td>'.$ID.'</td><td>'.$player.'</td><td>'.$commission.'</td><td>'.$dated.'</td><td>'.$tableID.'</td><td>'.$historyID.'</td></tr>';
        $html .= $rowHtml;
    }
    $html .=
            '</tbody>
                    </table>';

  
        $opsTheme->addVariable('html', $html);
        echo $opsTheme->viewPage('admin-profit');
?>
