

<?php 

    $html =
        '
                    <h3>Цэнэглэлтын түүх админ</h3>
                    <div class="table-responsive">
                        <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>№</th>
                                <th>Нэр</th>
                                <th>Дүн</th>
                                <th>Төлөв</th>
                                <th>Илгээсэн огноо</th>
                                <th>Шинэчлэгдсэн огноо</th>
                                <th>Зөвшөөрөл</th>
                                <th>Татгалзал</th>
                            </tr>
                        </thead>
                        <tbody>';
    $limit = 20;  //how many items to show per page
    $page = (isset($_GET['page'])) ? $_GET['page'] : 1;
    if($page)
    $start = ($page - 1) * $limit;      //first item to display on this page
    else
    $start = 0;
    $sql = "SELECT * FROM deposits ORDER BY id desc LIMIT $start, $limit";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $data = $stmt->fetchAll();

    foreach ($data as $row) {
        $id = $row['id'];
        $player_name = $row['player_name'];
        $amount = $row['amount'];
        $status = $row['status'];
        $created_at = $row['created_at'];
        $updated_at = $row['updated_at'];


        if ($status === '<span style="font-size: 15px;" class="badge badge-warning">Хүлээгдэж байна</span>') {

            $approveAction =
                '<td>
                <form method="post" action="admin.php?admin=deposit">
                    <input type="hidden" name="action" value="deposit_approve">
                    <input type="hidden" name="deposit_id" value="' . $id . '">
                    <button type="submit" class="btn btn-success">Зөвшөөрөх</button>
                </form>
            </td>';

            $denyAction =
                '<td>
                <form method="post" action="admin.php?admin=deny-deposit">
                    <input type="hidden" name="action" value="deny-deposit">
                    <input type="hidden" name="deposit_id" value="' . $id . '">
                    <button type="submit" class="btn btn-danger">Татгалзах</button>
                </form>
                
            </td>';
        } else {
            $approveAction = '<td></td>';
            $denyAction = '<td></td>';
        }
        $rowHtml = '<tr><td>'.$id.'</td><td>'.$player_name.'</td><td>'.$amount.'</td><td>'.$status.'</td><td>'.$created_at.'</td><td>'.$updated_at.'</td>'.$approveAction.$denyAction.'</tr>';
        $html .= $rowHtml;
    }
    $html .=
            '</tbody>
                    </table>
                    </div>';

  
        $opsTheme->addVariable('html', $html);
        echo $opsTheme->viewPage('admin-deposits');
?>
